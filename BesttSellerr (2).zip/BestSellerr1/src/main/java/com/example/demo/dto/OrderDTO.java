package com.example.demo.dto;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Entity

@Data

@Table(name ="orders")
public class OrderDTO {
	
	
	  private Long orderid;

	    private LocalDateTime orderDate;

	    private double totalAmt;
	    
	    public String orderStatus;

		public Long getOrderid() {
			return orderid;
		}

		public void setOrderid(Long orderid) {
			this.orderid = orderid;
		}

		public LocalDateTime getOrderDate() {
			return orderDate;
		}

		public void setOrderDate(LocalDateTime orderDate) {
			this.orderDate = orderDate;
		}

		public double getTotalAmt() {
			return totalAmt;
		}

		public void setTotalAmt(double totalAmt) {
			this.totalAmt = totalAmt;
		}

		public String getOrderStatus() {
			return orderStatus;
		}

		public void setOrderStatus(String orderStatus) {
			this.orderStatus = orderStatus;
		}

		public OrderDTO() {
			super();
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "OrderDTO [orderid=" + orderid + ", orderDate=" + orderDate + ", totalAmt=" + totalAmt
					+ ", orderStatus=" + orderStatus + "]";
		}
	    

}
