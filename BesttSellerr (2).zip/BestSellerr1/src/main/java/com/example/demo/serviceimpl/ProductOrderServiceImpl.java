package com.example.demo.serviceimpl;

public interface ProductOrderServiceImpl {

}
