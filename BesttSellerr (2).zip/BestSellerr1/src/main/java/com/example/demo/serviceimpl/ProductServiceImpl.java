package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ProductRepository;
import com.example.demo.entity.ProductEntity;
import com.example.demo.service.ProductService;

@Service

public class ProductServiceImpl implements ProductService {
	
	
	@Autowired
	private ProductRepository productRepository;
	
	

	@Override
	public ProductEntity createProduct(ProductEntity productEntity) {
		// TODO Auto-generated method stub
		return productRepository.save(productEntity);
	}

	@Override
	public List<ProductEntity> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
		

	}
	
	

}
