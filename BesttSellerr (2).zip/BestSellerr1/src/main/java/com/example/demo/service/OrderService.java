package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.OrderEntity;


public interface OrderService {
	
	  OrderEntity createOrder(OrderEntity orderEntity);
	    List<OrderEntity> getAllOrders();
		OrderEntity getOrderById(Long id);
		void deleteOrder(Long id);
		OrderEntity updateOrder(Long id, OrderEntity orderEntity);
		OrderEntity updateOrder(Long id, OrderEntity orderEntity);
		

}




