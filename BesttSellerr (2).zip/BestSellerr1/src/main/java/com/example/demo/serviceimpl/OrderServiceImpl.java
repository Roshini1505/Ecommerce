package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.OrderRepository;
import com.example.demo.entity.OrderEntity;
import com.example.demo.service.OrderService;

@Service

public class OrderServiceImpl implements OrderService {
	
	@Autowired
	
	private final OrderRepository orderRepository;
	
	

	@Override
	public OrderEntity createOrder(OrderEntity orderEntity) {
		// TODO Auto-generated method stub
		return orderRepository.save(orderEntity);
		
	}

	@Override
	public List<OrderEntity> getAllOrders() {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
		
	}
	
	

}
